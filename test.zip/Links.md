### Useful links for this course

* [Boltzmann Machine](http://www.scholarpedia.org/article/Boltzmann_machine)
